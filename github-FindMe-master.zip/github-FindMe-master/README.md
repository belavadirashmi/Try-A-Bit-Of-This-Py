# github-FindMe
SUMMARY & USAGE LICENSE
=============================================

FindMe project has been created as a learning exercise during my veg-at-home-time.
 
This project contains :

	* A program which accepts user input to carry out operations on a Email Account.
	
	* A function file to carry out the operations based on the input parameters. 
        
The program has been written in Python3.

CITATION AND REFERENCES
==============================================
Everything here is thanks to all of the below sources:

https://www.google.com

https://www.python.org/

https://www.pythoncentral.io

https://automatetheboringstuff.com

https://medium.freecodecamp.org/an-a-z-of-useful-python-tricks-b467524ee747

https://pypi.org/project/soundex/
