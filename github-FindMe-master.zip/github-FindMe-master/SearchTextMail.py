#!python3

import imaplib,smtplib,email,datetime,emoji,sys

def CheckMail(Domain,EmailId,Password,FolderName,SearchCriteria):
    conn= imaplib.IMAP4_SSL(Domain)
    print(conn)
    print("\n")
    type(conn)
    conn.login(EmailId,Password)
    conn.select(FolderName)
    resp, IDS = conn.search(None,SearchCriteria)
    numOfMails = len(IDS[0].split())
    print ("Number of emails found is : "+ str(numOfMails))
    print("\n")
    for i in range(numOfMails):
        print("------")
        print ("Index is "+str(i))
        print("\n")
        latestEmailID = IDS[0].split()[i]
        print ("Mail ID is "+str(latestEmailID))
        print("\n")
        res,CompleteMsg = conn.fetch(latestEmailID,'(RFC822)')
        print ("Response is :"+ str(res))
        print("\n")
        msgContent=email.message_from_bytes(CompleteMsg[0][1])
        print ("Mail for this Mail ID is :" + str(msgContent))
        print("------")
        emailSub=msgContent['subject']
        print("Subject is : "+str(emailSub))
        emailFrom=msgContent['from']
        print("Sender is : "+str(emailFrom))
        emailTo=msgContent['to']
        print("Recipient is : "+str(emailTo))
        StrMsgContent=email.message_from_string(CompleteMsg[0][1].decode('utf-8'))
        for part in StrMsgContent.walk():
            if part.get_content_type() == "text/plain":
                body = part.get_payload(decode=True)
                print("Content is : "+str(body.decode('utf-8')))
    print ("\nCheckMail Complete\n")
    
Domain=sys.argv[1]
EmailId=sys.argv[2]
Password=sys.argv[3]
FolderName=sys.argv[4]
SearchCriteria=sys.argv[5]
print ("Arguments passed were the below:\nDomain-",Domain,",EmailId-",EmailId,",Password-",Password,",FolderName-",FolderName,",SearchCriteria-",SearchCriteria)

CheckMail(Domain,EmailId,Password,FolderName,SearchCriteria)
print (emoji.emojize(":thumbs_up:"))
